print('Hello from a Python snippet')
